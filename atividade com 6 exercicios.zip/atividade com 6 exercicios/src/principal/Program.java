package principal;

import java.util.Scanner;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner leia = new Scanner(System.in);
		
    int numero;
    System.out.println(" Digite um n�mero: ");
	numero = leia.nextInt();
	System.out.println(numero);
	
	
	}
	
	

}
