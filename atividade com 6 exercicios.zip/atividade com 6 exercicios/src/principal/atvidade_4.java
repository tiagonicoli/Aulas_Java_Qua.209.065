package principal;

import java.util.Scanner;

public class atvidade_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner leia = new Scanner(System.in);
		double nota1;
		double nota2;
		double nota3;
		double nota4;
		System.out.println("digite a primeira nota");
		nota1 = leia.nextDouble();
		System.out.println("digite a segunda nota");
		nota2 = leia.nextDouble();
		System.out.println("digite a terceira nota");
		nota3 = leia.nextDouble();
		System.out.println("digite a quarta nota");
		nota4 = leia.nextDouble();
		System.out.println("A m�dia das notas � de: " + (nota1 + nota2 + nota3 + nota4) /4 );
		leia.close();
		

	}

}
