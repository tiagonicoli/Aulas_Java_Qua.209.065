package principal;

import java.util.Scanner;

public class atividade_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner leia = new Scanner(System.in);
		
		int num1;
		int num2;
		System.out.println(" Entre com o primeiro n�mero");
		num1 = leia.nextInt();
		System.out.println("Entre com o segundo numero");
		num2 = leia.nextInt();
		
		System.out.println("A Soma dos dois n�meros � " + (num1 + num2));
		
		leia.close();
		
		
		
		

	}

}
